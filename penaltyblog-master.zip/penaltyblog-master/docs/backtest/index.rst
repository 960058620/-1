Backtest
==========================

Functions for backtesting betting strategy

.. toctree::
   :maxdepth: 1
   :caption: Examples:

   backtest
