Fantasy Premier League
==========================

Functions for scraping data from the Fantasy Premier League website, and for mathematically optimising your football team to identify the highest scoring combination of players per formation for a specified budget.

.. toctree::
   :maxdepth: 1
   :caption: Examples:

   fpl
