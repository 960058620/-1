Implied Odds
==============

Functions for estimating the implied odds from bookmaker's odds. Includes multiple different algorithms, including Shin's method

.. toctree::
   :maxdepth: 1
   :caption: Examples:

   implied
