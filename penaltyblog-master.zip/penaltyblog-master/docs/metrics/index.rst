Metrics
============

Useful functions for working with football (soccer) data, such as ranked probability scores (RPS) for
measuring the performance of football model predictions.

.. toctree::
   :maxdepth: 1
   :caption: Examples:

   rps
