Ratings / Rankings
===================

Models for rating / ranking football (soccer) teams.

.. toctree::
   :maxdepth: 1
   :caption: Examples:

   colley_ratings
   massey_ratings
   elo_ratings
